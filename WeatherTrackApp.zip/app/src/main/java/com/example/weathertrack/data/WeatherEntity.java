package com.example.weathertrack.data;

public class WeatherEntity {
    public String date;
    public float temperature;
    public int humidity;
    public String condition;

    public WeatherEntity(String date, float temperature, int humidity, String condition) {
        this.date = date;
        this.temperature = temperature;
        this.humidity = humidity;
        this.condition = condition;
    }
}
