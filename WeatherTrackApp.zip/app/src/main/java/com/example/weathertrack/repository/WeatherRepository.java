package com.example.weathertrack.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.weathertrack.data.WeatherEntity;
import java.util.ArrayList;
import java.util.List;

public class WeatherRepository {
    public LiveData<List<WeatherEntity>> getWeatherData() {
        MutableLiveData<List<WeatherEntity>> data = new MutableLiveData<>();
        List<WeatherEntity> dummy = new ArrayList<>();
        dummy.add(new WeatherEntity("2024-06-01", 32.5f, 80, "Sunny"));
        dummy.add(new WeatherEntity("2024-06-02", 30.2f, 78, "Cloudy"));
        data.setValue(dummy);
        return data;
    }
}
