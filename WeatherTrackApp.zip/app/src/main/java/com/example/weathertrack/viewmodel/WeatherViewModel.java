package com.example.weathertrack.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.weathertrack.data.WeatherEntity;
import com.example.weathertrack.repository.WeatherRepository;
import java.util.List;

public class WeatherViewModel extends ViewModel {
    private final WeatherRepository repository = new WeatherRepository();
    public LiveData<List<WeatherEntity>> getWeatherData() {
        return repository.getWeatherData();
    }
}
